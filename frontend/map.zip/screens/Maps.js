import * as React from "react";
import {
  View,
  StyleSheet,
  Text,
  Pressable,
  ImageBackground,
  TextInput,
} from "react-native";
import { Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const Maps = () => {
  return (
    <View style={styles.maps1}>
      <View style={[styles.maps, styles.mapsLayout]} />
      <View style={[styles.navBar, styles.mapsLayout]} />
      <Text style={[styles.activity, styles.homeTypo]}>Activity</Text>
      <Text style={[styles.home, styles.homeTypo]}>home</Text>
      <Text style={[styles.profile, styles.homeTypo]}>profile</Text>
      <View style={[styles.maps1Child, styles.mapsLayout]} />
      <View style={[styles.search, styles.mapsLayout]} />
      <Text style={styles.enterDestination}>Enter Destination</Text>
      <Pressable style={[styles.enter, styles.enterPosition]} />
      <View style={styles.maps1Item} />
      <Text style={[styles.enter1, styles.enterPosition]}>Enter</Text>
      <ImageBackground
        style={styles.addressIcon}
        resizeMode="cover"
        source={require("../assets/address.png")}
      />
      <Text style={styles.goodMorning}>Good Morning!</Text>
      <TextInput style={styles.destInput} />
      <ImageBackground
        style={[styles.garbageTruckIcon, styles.iconPosition1]}
        resizeMode="cover"
        source={require("../assets/garbagetruck.png")}
      />
      <ImageBackground
        style={[styles.homePageIcon, styles.iconPosition1]}
        resizeMode="cover"
        source={require("../assets/homepage.png")}
      />
      <ImageBackground
        style={[styles.accountIcon, styles.iconPosition1]}
        resizeMode="cover"
        source={require("../assets/account.png")}
      />
      <ImageBackground
        style={[styles.alarmIcon, styles.iconPosition]}
        resizeMode="cover"
        source={require("../assets/alarm.png")}
      />
      <ImageBackground
        style={[styles.menuIcon, styles.iconPosition]}
        resizeMode="cover"
        source={require("../assets/menu.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  mapsLayout: {
    borderRadius: Border.br_13xl,
    position: "absolute",
  },
  homeTypo: {
    height: 15,
    width: 45,
    textAlign: "center",
    color: Color.colorBlack,
    fontFamily: FontFamily.jostMedium,
    fontWeight: "500",
    fontSize: FontSize.size_smi,
    position: "absolute",
  },
  enterPosition: {
    top: 181,
    position: "absolute",
  },
  iconPosition1: {
    top: 702,
    height: 30,
    position: "absolute",
  },
  iconPosition: {
    height: 26,
    top: 38,
    position: "absolute",
  },
  maps: {
    left: 8,
    backgroundColor: "#d9d9d9",
    width: 340,
    height: 601,
    top: 165,
  },
  navBar: {
    top: 697,
    left: 28,
    width: 301,
    height: 69,
    backgroundColor: Color.colorLimegreen,
  },
  activity: {
    top: 734,
    left: 76,
  },
  home: {
    top: 737,
    left: 168,
  },
  profile: {
    top: 736,
    left: 257,
  },
  maps1Child: {
    top: 24,
    left: 5,
    width: 350,
    height: 141,
    backgroundColor: Color.colorLimegreen,
  },
  search: {
    top: 107,
    left: 26,
    width: 303,
    height: 116,
    backgroundColor: Color.colorWhite,
  },
  enterDestination: {
    top: 117,
    left: 150,
    height: 20,
    width: 108,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.jostMedium,
    fontWeight: "500",
    fontSize: FontSize.size_smi,
    position: "absolute",
  },
  enter: {
    left: 159,
    borderRadius: 29,
    height: 25,
    width: 108,
    backgroundColor: Color.colorLimegreen,
  },
  maps1Item: {
    left: 137,
    borderStyle: "solid",
    borderColor: Color.colorBlack,
    borderTopWidth: 1,
    width: 142,
    height: 1,
    top: 165,
    position: "absolute",
  },
  enter1: {
    left: 184,
    width: 56,
    height: 16,
    textAlign: "center",
    color: Color.colorBlack,
    fontFamily: FontFamily.jostMedium,
    fontWeight: "500",
    fontSize: FontSize.size_smi,
    top: 181,
  },
  addressIcon: {
    top: 135,
    left: 75,
    height: 30,
    width: 30,
    position: "absolute",
  },
  goodMorning: {
    left: 37,
    fontSize: FontSize.size_base,
    width: 193,
    height: 41,
    top: 38,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.jostMedium,
    fontWeight: "500",
    position: "absolute",
  },
  destInput: {
    top: 137,
    left: 134,
    width: 139,
    height: 23,
    position: "absolute",
    backgroundColor: Color.colorWhite,
  },
  garbageTruckIcon: {
    left: 87,
    width: 30,
    top: 702,
  },
  homePageIcon: {
    left: 174,
    width: 30,
    top: 702,
  },
  accountIcon: {
    left: 261,
    width: 34,
  },
  alarmIcon: {
    left: 244,
    width: 27,
  },
  menuIcon: {
    left: 295,
    width: 29,
  },
  maps1: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
    backgroundColor: Color.colorWhite,
  },
});

export default Maps;
